import setuptools

setuptools.setup(
    name='denpac',
    version='0.0.1',
    author='Denis',
    author_email='your@domain.com',
    description='My Package',
    packages=setuptools.find_packages(),
)