def to_uppercase(s):
    s = str(s)
    return s.upper()


def reverse(s):
    s = str(s)
    return s[::-1]
